package com.bakhi.client;

import com.bakhi.network.BaKhiNetworking;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

/** Both keys default to UNBOUND; bind them in Options > Controls > Bá Khí. */
public class BaKhiClient implements ClientModInitializer {

    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("bakhi", "main"));

    private static KeyMapping saveLayoutKey;
    private static KeyMapping clearLayoutKey;

    @Override
    public void onInitializeClient() {
        saveLayoutKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.bakhi.save_layout", InputConstants.UNKNOWN.getValue(), CATEGORY));
        clearLayoutKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.bakhi.clear_layout", InputConstants.UNKNOWN.getValue(), CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (saveLayoutKey.consumeClick()) {
                ClientPlayNetworking.send(new BaKhiNetworking.SaveLayoutPayload());
            }
            while (clearLayoutKey.consumeClick()) {
                ClientPlayNetworking.send(new BaKhiNetworking.ClearLayoutPayload());
            }
        });
    }
}

package com.bakhi;

import com.bakhi.config.BaKhiConfig;
import com.bakhi.core.DropScheduler;
import com.bakhi.core.SortScheduler;
import com.bakhi.network.BaKhiNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

/**
 * Common entrypoint (runs on both integrated and dedicated server).
 *
 * Design summary:
 *  - ItemEntityMixin captures a before/after item count around every player pickup
 *    collision (see PickupTracker) so we only ever act on the item COUNT THAT WAS
 *    ACTUALLY GAINED, never the whole stack blindly.
 *  - Nothing is mutated inside that same collision call stack. Every reaction
 *    (sort or trash) is queued and processed on a later server tick, which is the
 *    main defense against "ghost item" duplication bugs caused by fighting vanilla's
 *    own insert/merge logic mid-call.
 *  - Trash drops re-check the player's current count right before removing anything,
 *    so an item the player already used/moved during the delay window is never
 *    wrongly taken.
 */
public class BaKhiMod implements ModInitializer {
    public static final String MOD_ID = "bakhi";

    @Override
    public void onInitialize() {
        BaKhiConfig.load();

        ServerTickEvents.END_SERVER_TICK.register(DropScheduler::tick);
        ServerTickEvents.END_SERVER_TICK.register(SortScheduler::tick);

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> BaKhiConfig.get().save());

        BaKhiNetworking.registerServerReceivers();
    }
}

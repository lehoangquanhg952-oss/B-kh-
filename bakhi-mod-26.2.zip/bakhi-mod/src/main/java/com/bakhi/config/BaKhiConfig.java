package com.bakhi.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Persistent config for "Bá Khí", saved to config/bakhi.json.
 *
 * - blacklist / whitelist store item ids as strings, e.g. "minecraft:cobblestone".
 * - savedLayout maps an item id to the ordered list of inventory slot indices (0-35,
 *   hotbar is 0-8) that were holding that item when the layout was last saved. Only
 *   consulted for whitelist items.
 * - Per spec: an item that is on NEITHER list is treated as trash (same as blacklist).
 */
public final class BaKhiConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("bakhi.json");

    public Set<String> blacklist = new LinkedHashSet<>();
    public Set<String> whitelist = new LinkedHashSet<>();
    public Map<String, List<Integer>> savedLayout = new LinkedHashMap<>();
    public int dropDelayTicks = 20; // 20 ticks = 1 second at normal tick rate

    private static BaKhiConfig instance;

    public static BaKhiConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    public static BaKhiConfig load() {
        if (Files.exists(FILE)) {
            try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
                BaKhiConfig cfg = GSON.fromJson(reader, BaKhiConfig.class);
                if (cfg != null) {
                    instance = cfg;
                    return cfg;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        instance = new BaKhiConfig();
        instance.save();
        return instance;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

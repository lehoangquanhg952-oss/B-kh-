package com.bakhi.network;

import com.bakhi.config.BaKhiConfig;
import com.bakhi.core.InventoryUtil;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;

/** Client -> server packets: save / clear the inventory layout. */
public final class BaKhiNetworking {
    private BaKhiNetworking() {}

    public record SaveLayoutPayload() implements CustomPacketPayload {
        public static final Type<SaveLayoutPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath("bakhi", "save_layout"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SaveLayoutPayload> CODEC =
                StreamCodec.unit(new SaveLayoutPayload());

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record ClearLayoutPayload() implements CustomPacketPayload {
        public static final Type<ClearLayoutPayload> TYPE =
                new Type<>(Identifier.fromNamespaceAndPath("bakhi", "clear_layout"));
        public static final StreamCodec<RegistryFriendlyByteBuf, ClearLayoutPayload> CODEC =
                StreamCodec.unit(new ClearLayoutPayload());

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    private static void registerPayloadTypes() {
        PayloadTypeRegistry.serverboundPlay().register(SaveLayoutPayload.TYPE, SaveLayoutPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(ClearLayoutPayload.TYPE, ClearLayoutPayload.CODEC);
    }

    public static void registerServerReceivers() {
        registerPayloadTypes();

        ServerPlayNetworking.registerGlobalReceiver(SaveLayoutPayload.TYPE, (payload, context) ->
                context.server().execute(() -> {
                    var player = context.player();
                    var inv = player.getInventory();
                    BaKhiConfig cfg = BaKhiConfig.get();

                    cfg.savedLayout.clear();
                    for (int slot = 0; slot < InventoryUtil.INVENTORY_SIZE; slot++) {
                        var stack = inv.getItem(slot);
                        if (stack.isEmpty()) continue;
                        String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
                        cfg.savedLayout.computeIfAbsent(id, k -> new ArrayList<>()).add(slot);
                    }
                    cfg.save();
                    player.sendSystemMessage(Component.literal("[Bá Khí] Đã lưu bố cục túi đồ."), true);
                }));

        ServerPlayNetworking.registerGlobalReceiver(ClearLayoutPayload.TYPE, (payload, context) ->
                context.server().execute(() -> {
                    BaKhiConfig cfg = BaKhiConfig.get();
                    cfg.savedLayout.clear();
                    cfg.save();
                    context.player().sendSystemMessage(Component.literal("[Bá Khí] Đã xoá bố cục đã lưu."), true);
                }));
    }
}

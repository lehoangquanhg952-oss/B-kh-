package com.bakhi.mixin;

import com.bakhi.core.PickupTracker;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Observes vanilla's pickup (ItemEntity#playerTouch, Mojang name) without changing it:
 * snapshot at HEAD, compute the real delta at TAIL. Server-side players only.
 */
@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin {

    @Unique
    private ItemStack bakhi$pendingSnapshot;

    @Inject(method = "playerTouch", at = @At("HEAD"))
    private void bakhi$beforePickup(Player player, CallbackInfo ci) {
        if (!(player instanceof ServerPlayer)) return;
        ItemEntity self = (ItemEntity) (Object) this;
        ItemStack snapshot = self.getItem().copy();
        bakhi$pendingSnapshot = snapshot;
        PickupTracker.beforePickup(player, snapshot);
    }

    @Inject(method = "playerTouch", at = @At("TAIL"))
    private void bakhi$afterPickup(Player player, CallbackInfo ci) {
        if (!(player instanceof ServerPlayer) || bakhi$pendingSnapshot == null) return;
        PickupTracker.afterPickup(player, bakhi$pendingSnapshot);
        bakhi$pendingSnapshot = null;
    }
}

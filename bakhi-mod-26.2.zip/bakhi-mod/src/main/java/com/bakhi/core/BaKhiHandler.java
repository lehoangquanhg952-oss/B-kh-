package com.bakhi.core;

import com.bakhi.config.BaKhiConfig;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.core.registries.BuiltInRegistries;

/**
 * Decides what happens to a just-gained item, per spec:
 *  - whitelist            -> auto-sort into saved layout slots
 *  - blacklist, OR         -> auto-drop (delayed)
 *    not on either list
 * If an item somehow ends up on both lists, blacklist wins (trash is the safer default).
 */
public final class BaKhiHandler {
    private BaKhiHandler() {}

    public static void onItemGained(Player player, Item item, int gained) {
        BaKhiConfig cfg = BaKhiConfig.get();
        String id = BuiltInRegistries.ITEM.getKey(item).toString();

        boolean blacklisted = cfg.blacklist.contains(id);
        boolean whitelisted = cfg.whitelist.contains(id) && !blacklisted;

        if (whitelisted) {
            SortScheduler.enqueue(player, item, gained);
        } else {
            DropScheduler.enqueue(player, item, gained, cfg.dropDelayTicks);
        }
    }
}

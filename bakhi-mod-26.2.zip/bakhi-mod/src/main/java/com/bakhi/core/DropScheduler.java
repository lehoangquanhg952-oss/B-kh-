package com.bakhi.core;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Delays trash drops by a configurable number of ticks instead of removing items the
 * instant they are picked up.
 *
 * Why a delay + a later re-check, and not an instant removal:
 *  1. It never mutates the inventory from inside the same call stack as vanilla's own
 *     pickup/merge logic (ItemEntity#onPlayerCollision) — that kind of re-entrant
 *     mutation is the most common cause of item duplication / "ghost" stacks.
 *  2. Right before actually dropping, it re-counts how many the player currently has
 *     and only ever drops min(originally gained, currently held). If the player crafted
 *     with it, traded it, or otherwise got rid of some of it during the delay window,
 *     those are never touched — only the amount still provably "extra" is dropped.
 */
public final class DropScheduler {
    private DropScheduler() {}

    private record Pending(Item item, int amount, int ticksLeft) {
        Pending withTicksLeft(int t) { return new Pending(item, amount, t); }
    }

    private static final Map<UUID, List<Pending>> QUEUE = new ConcurrentHashMap<>();

    public static void enqueue(net.minecraft.world.entity.player.Player player, Item item, int amount, int delayTicks) {
        QUEUE.computeIfAbsent(player.getUUID(), k -> new ArrayList<>())
             .add(new Pending(item, amount, Math.max(delayTicks, 1)));
    }

    public static void tick(MinecraftServer server) {
        if (QUEUE.isEmpty()) return;

        for (Map.Entry<UUID, List<Pending>> entry : QUEUE.entrySet()) {
            List<Pending> list = entry.getValue();
            if (list.isEmpty()) continue;

            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player == null) {
                list.clear();
                continue;
            }

            List<Pending> remaining = new ArrayList<>(list.size());
            for (Pending p : list) {
                int left = p.ticksLeft() - 1;
                if (left > 0) {
                    remaining.add(p.withTicksLeft(left));
                    continue;
                }

                int have = InventoryUtil.countOf(player.getInventory(), p.item());
                int toDrop = Math.min(have, p.amount());
                if (toDrop > 0) {
                    InventoryUtil.removeUpTo(player.getInventory(), p.item(), toDrop);
                    ItemStack dropStack = new ItemStack(p.item(), toDrop);
                    // Reuses vanilla's own drop (same arc / velocity / pickup-delay as a
                    // normal Q-drop) instead of hand-spawning an ItemEntity, so the dropped
                    // trash behaves identically to any other item on the ground.
                    player.drop(dropStack, false);
                }
                // toDrop == 0 means the player no longer has any of it left — nothing to do,
                // and nothing was wrongly removed.
            }
            list.clear();
            list.addAll(remaining);
        }
    }
}

package com.bakhi.core;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Captures an inventory item-count snapshot immediately before a pickup collision, and
 * compares it to the count immediately after, so the mod only ever reacts to the exact
 * amount actually gained (delta) — never the full ground stack, since a nearly-full
 * inventory may only accept part of it, or none at all.
 */
public final class PickupTracker {
    private PickupTracker() {}

    // playerUUID -> (item -> count observed right before this pickup)
    private static final Map<UUID, Map<Item, Integer>> BEFORE = new HashMap<>();

    public static void beforePickup(Player player, ItemStack incoming) {
        if (incoming.isEmpty()) return;
        Item item = incoming.getItem();
        int before = InventoryUtil.countOf(player.getInventory(), item);
        BEFORE.computeIfAbsent(player.getUUID(), k -> new HashMap<>()).put(item, before);
    }

    public static void afterPickup(Player player, ItemStack incoming) {
        if (incoming.isEmpty()) return;
        Item item = incoming.getItem();

        Map<Item, Integer> map = BEFORE.get(player.getUUID());
        if (map == null) return;
        Integer before = map.remove(item);
        if (before == null) return;

        int after = InventoryUtil.countOf(player.getInventory(), item);
        int gained = after - before;
        if (gained <= 0) return; // inventory was full (or item bounced off armor slot etc.) — nothing to do

        BaKhiHandler.onItemGained(player, item, gained);
    }
}

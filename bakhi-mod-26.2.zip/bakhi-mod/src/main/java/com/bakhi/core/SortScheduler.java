package com.bakhi.core;

import com.bakhi.config.BaKhiConfig;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Re-sorts newly gained whitelist items into their saved layout slots, one tick after
 * the pickup collision (never inside the same call stack as vanilla's insertStack logic
 * — see DropScheduler's class comment for why that matters).
 *
 * Only ever acts on the delta amount that was actually gained this pickup; a player's
 * pre-existing stock of that item is never touched or re-shuffled on its own.
 */
public final class SortScheduler {
    private SortScheduler() {}

    private record Pending(Item item, int amount) {}

    private static final Map<UUID, List<Pending>> QUEUE = new ConcurrentHashMap<>();

    public static void enqueue(Player player, Item item, int amount) {
        QUEUE.computeIfAbsent(player.getUUID(), k -> new ArrayList<>()).add(new Pending(item, amount));
    }

    public static void tick(MinecraftServer server) {
        if (QUEUE.isEmpty()) return;

        for (Map.Entry<UUID, List<Pending>> entry : QUEUE.entrySet()) {
            List<Pending> list = entry.getValue();
            if (list.isEmpty()) continue;

            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player == null) {
                list.clear();
                continue;
            }

            BaKhiConfig cfg = BaKhiConfig.get();
            Inventory inv = player.getInventory();

            for (Pending p : list) {
                String id = BuiltInRegistries.ITEM.getKey(p.item()).toString();
                List<Integer> preferred = cfg.savedLayout.getOrDefault(id, List.of());
                int maxStack = new ItemStack(p.item()).getMaxStackSize();

                int leftover = preferred.isEmpty()
                        ? p.amount()
                        : InventoryUtil.fillPreferredSlots(inv, p.item(), p.amount(), preferred, maxStack);

                if (leftover > 0) {
                    leftover = InventoryUtil.fillAnywhere(inv, p.item(), leftover, maxStack);
                }
                if (leftover > 0) {
                    // Inventory is genuinely full everywhere: drop the overflow at the
                    // player's feet instead of discarding it, so nothing ever just vanishes.
                    player.drop(new ItemStack(p.item(), leftover), false);
                }
            }
            list.clear();
        }
    }
}

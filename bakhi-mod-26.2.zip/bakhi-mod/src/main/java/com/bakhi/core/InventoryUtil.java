package com.bakhi.core;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Pure helper functions over a Inventory's main 36 slots (hotbar 0-8 + the rest
 * 9-35). No side effects unless the method name says remove/fill. Armor and offhand are
 * intentionally excluded since the mod only ever deals with items picked up off the
 * ground into the main inventory.
 */
public final class InventoryUtil {
    private InventoryUtil() {}

    public static final int INVENTORY_SIZE = 36;

    public static int countOf(Inventory inv, Item item) {
        int total = 0;
        for (int i = 0; i < INVENTORY_SIZE; i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.getItem() == item) total += stack.getCount();
        }
        return total;
    }

    public static List<Integer> emptySlots(Inventory inv) {
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < INVENTORY_SIZE; i++) {
            if (inv.getItem(i).isEmpty()) slots.add(i);
        }
        return slots;
    }

    /**
     * Removes up to {@code amount} total of {@code item}, preferring to fully empty
     * partially-filled stacks (never leaves a 0-count stack sitting in a slot). Returns
     * how many were actually removed, which may be less than requested if the player no
     * longer has that many — callers must use the return value, not assume success.
     */
    public static int removeUpTo(Inventory inv, Item item, int amount) {
        int remaining = amount;
        for (int i = 0; i < INVENTORY_SIZE && remaining > 0; i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.getItem() != item) continue;
            int take = Math.min(stack.getCount(), remaining);
            stack.shrink(take);
            if (stack.isEmpty()) {
                inv.setItem(i, ItemStack.EMPTY);
            }
            remaining -= take;
        }
        return amount - remaining;
    }

    /**
     * Tops off existing stacks of {@code item} inside {@code preferredSlots} first, then
     * uses empty slots within {@code preferredSlots}. Returns the leftover count that did
     * not fit in the preferred slots (0 if everything fit) — the caller is responsible for
     * placing that leftover somewhere (fillAnywhere, or dropping it), it is never dropped
     * or deleted by this method.
     */
    public static int fillPreferredSlots(Inventory inv, Item item, int amount,
                                          List<Integer> preferredSlots, int maxStackSize) {
        int remaining = amount;

        for (int slot : preferredSlots) {
            if (remaining <= 0) break;
            ItemStack stack = inv.getItem(slot);
            if (stack.getItem() == item && stack.getCount() < maxStackSize) {
                int add = Math.min(maxStackSize - stack.getCount(), remaining);
                stack.grow(add);
                remaining -= add;
            }
        }

        for (int slot : preferredSlots) {
            if (remaining <= 0) break;
            if (inv.getItem(slot).isEmpty()) {
                int add = Math.min(maxStackSize, remaining);
                inv.setItem(slot, new ItemStack(item, add));
                remaining -= add;
            }
        }

        return remaining;
    }

    /**
     * Fallback placement: tops off any other existing stack of {@code item} anywhere in
     * the inventory, then uses any empty slot. Returns leftover that genuinely did not
     * fit anywhere (inventory full) — the caller must drop this, never silently discard
     * it, or items disappear.
     */
    public static int fillAnywhere(Inventory inv, Item item, int amount, int maxStackSize) {
        int remaining = amount;

        for (int i = 0; i < INVENTORY_SIZE && remaining > 0; i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.getItem() == item && stack.getCount() < maxStackSize) {
                int add = Math.min(maxStackSize - stack.getCount(), remaining);
                stack.grow(add);
                remaining -= add;
            }
        }
        for (int i = 0; i < INVENTORY_SIZE && remaining > 0; i++) {
            if (inv.getItem(i).isEmpty()) {
                int add = Math.min(maxStackSize, remaining);
                inv.setItem(i, new ItemStack(item, add));
                remaining -= add;
            }
        }

        return remaining;
    }
}

# Bá Khí (Minecraft 26.2, Fabric)

Tự xếp item whitelist vào layout đã lưu; tự vứt item blacklist / không nằm trong danh sách khi nhặt (có delay).

- Cấu hình: sửa file `config/bakhi.json` (blacklist, whitelist, dropDelayTicks). Id item dạng `minecraft:ender_pearl`.
- Phím Save/Clear Layout: gán trong Options > Controls > Bá Khí.
- Item không nằm trong whitelist lẫn blacklist sẽ bị vứt. Hãy thêm whitelist trước khi chơi thật.

## Build
Push lên GitHub, vào tab Actions, tải artifact `bakhi-jar` (Java 25, Gradle 9.5.1).

## Chưa verify
Chưa build thật. Nếu Actions báo lỗi, gửi log của bước lỗi.
